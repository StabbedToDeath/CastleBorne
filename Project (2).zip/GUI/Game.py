import Player
import CombatSystem
import Room
import random
class Game():
    '''represents the game'''
    def __init__(self, page):
        '''initializing variables'''
        self.page = page
        self.rooms = [[0 for i in range(4)] for i in range(4)]
        self.loadRooms()
        self.player = Player.Player(page, self)
        self.combat = CombatSystem.CombatSystem(page, self.player)
        self.endGame = False
        
    def loadRooms(self):
        '''initializing rooms'''
        objectsFile = open("data/Objects.txt","r")
        with open("data/rooms.txt", "r") as f:
            for line in f:
                l = map(str.strip, line.split("="))
                self.rooms[int(l[1][1])][int(l[1][-2])] = Room.Room(self.page, objectsFile, l[0])
        objectsFile.close()

    def placeKeyDefault(self):
        '''placing key in a random room'''
        while True:
            x = random.randint(0,3)
            y = random.randint(0,3)
            if self.rooms[x][y].container != {}:
                Room.Room.isKeyPlaced = True
                Room.Room.keyRoom = self.rooms[x][y]
                self.rooms[x][y].object.update({"Throne Room Key":"take"})# adding throne room key to the room
                l = self.rooms[x][y].container['chest']
                l.append("Throne Room Key")
                self.rooms[x][y].container['chest'] = l
                self.rooms[x][y].objectsInRoom = dict(self.rooms[x][y].object)
                break