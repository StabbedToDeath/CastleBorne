import random
import Enemy
class CombatSystem:
    '''represents the combat system'''
    def __init__(self, page, player):
        '''initialising variables'''
        self.player = player
        self.playerDamageAbsorb = 1
        self.enemies = {}
        self.gamePage = page
        self.isAttacking = False
        self.isUsingItem = False
        self.inCombat = False
        
    def initCombat(self):
        '''initialing combat'''
        if self.enemies!={}:
            return
        self.enemies = {}
        self.playerDamageAbsorb = self.player.getArmorRating()
        for t in self.player.currentRoom.enemies:
            for i in range(t[1]):
                self.enemies[(t[0]+(" "+str(i+1) if t[1]!=1 else "")).lower()] = Enemy.Enemy(t[0], t[-1])
                
                
    def checkCommandAndCall(self, choice):
        '''checking commands and calling appropriate functions'''
        
        if self.isAttacking:
            return self.attack(choice)
        
        elif self.isUsingItem:
            return self.useAnItem(choice)
                    
        elif choice == "attack":
            return self.attack()
        
        elif choice == "defend":
            return self.defend()
        
        elif choice == "use an item":
            return self.useAnItem()
        
        #cheat
        elif choice == "kill all":
            self.enemies = {}
            self.inCombat = False
            return ""
        
        return ("\nYou cannot do that") 
             
        
    def attack(self, target=None):
        '''when player attacks'''
        if not self.inCombat:
            return ""
        toReturn = ""
        if not self.isAttacking:
            toReturn = self.displayEnemies()
            self.isAttacking = True
            return toReturn + "\nWhich enemy do you want to attack? "
            
        if target not in self.enemies:
            return ("\nThat enemy is not present.\nWhich enemy do you want to attack?\n")
            
        self.enemies[target].health-=(self.player.getAttackPower()/self.enemies[target].defenceMult) # decreasing targets health
        self.isAttacking = False
        if self.enemies[target].health<1:
            toReturn =  ("\nYou killed "+target+"!")
            self.enemies.pop(target)
        else:
            toReturn = ("\nYou attacked "+target+"!")
        if "bucket" in self.player.inventory:
            return toReturn + ("\nYou have done one hundred novemdecillion(10^62) attack damage!!!!!!!!!!!") #special message
        return toReturn
    
    def defend(self):
        '''when player defends'''
        if not self.inCombat:
            return ""
        self.playerDamageAbsorb = self.player.defenceMult+random.uniform(0.5, 1)# setting player defense variable
        return ("\nYou have defended!")
    
    def useAnItem(self, item=None):
        '''when player uses an item'''
        if not self.inCombat:
            return ""
        l = []
        toReturn = ""
        for i in self.player.inventory:
            if self.player.isConsumable(i):
                l.append(i)
        if l!=[]:
            if not self.isUsingItem:
                toReturn += ("\nThe items you can use are:\n")
                # displaying usable items
                for item in l:
                    toReturn+=(item+"\n")
                self.isUsingItem = True
                return toReturn + "\nWhich item do you want to use? "
            if item not in l:
                return ("\nyou cannot use that item")
            
            self.isUsingItem = False
            return self.player.consume(item) # consuming item
            
        else:
            return ("\nyou don't have any items you can use during combat.")
        
    
    def enemiesAttack(self):
        '''for enemy attacks'''
        if not self.inCombat:
            return ""
        toReturn = ""
        enemiesAttackDamage = []
        for enemy in self.enemies:
            self.enemies[enemy].defenceMult = 1
            notMiss = bool(random.randint(0,3))
            if not notMiss:
                toReturn += ("\n"+enemy+" has missed his attack!")
                
            attackChance = bool(random.randint(0,3))
            if attackChance and notMiss:
                attack = self.enemies[enemy].getAttack()
                toReturn+=("\n"+enemy+attack[0])
                attackDamage = attack[1]/self.playerDamageAbsorb # attacking player
                self.player.health-= attackDamage
                enemiesAttackDamage.append(attackDamage)
                
            elif notMiss and not attackChance:
                self.enemies[enemy].defenceMult+=random.uniform(0.25,0.75) # defending
                toReturn+=("\n"+enemy+ " has defended!")
                
        self.playerDamageAbsorb = self.player.getArmorRating()
        return toReturn, enemiesAttackDamage
    
    def isCombatOver(self):
        '''checking if combat is over'''
        toReturn = ""
        if self.enemies == {}:
            toReturn+=("\nYou have won the battle!\n")
            self.player.currentRoom.enemies = []
            if self.player.currentRoom.ID == "[THRONEROOM]":
                toReturn+=("\nYou rummage through the corpse, looking for something of value. You find a large number of items, despite the fact that the monster didn't have pockets to begin with. You also find a rusty key, which looks like it fits into the lock of the castle's main door. Nearly crying with joy, you realize that you can finally get out of this hell hole. You make your way to the lobby.\n")
                self.player.inventory.update({"Castle Key":"take"})
                self.gamePage.updateInventory()
            
            self.inCombat = False
        return toReturn
          
    
                    
    def displayEnemies(self):
        ''' displays enemies in room along with their healths'''
        toReturn = ("\nEnemies around you:\n")
        for i in self.enemies:
            toReturn+=(i+"%30d"%self.enemies[i].health+"\n")
        return toReturn+"\n"
