import random
class Player():
    ''' a class that represents the player'''
    def __init__(self ,page, game):
        # initializing the variables
        self.x = 0
        self.y = 2
        self.currentRoom = game.rooms[self.x][self.y]
        self.inventory = {}
        self.game = game
        self.health = 1000
        self.max_health = 1000
        self.defenceMult = 1
        self.directions = ["north", "south", "east", "west"]
        self.vowels= ["a","e","i","o","u"]
        self.gamePage = page
        self.roomChange = False
        

    def goto(self,direction):
        ''' changes the player location according to the input'''
        pastX = self.x
        pastY = self.y
        # checking if direction is valid and applying necessary changes
        if direction == "north" and self.x-1>=0:
            self.x-=1
        elif direction == "south" and self.x+1<=3:
            self.x+=1
        elif direction == "east" and self.y+1<=3:
            self.y+=1
        elif direction == "west" and self.y-1>=0:
            self.y-=1
        elif direction == "north" and self.currentRoom.ID == "[LOBBY]":
            if "Castle Key" in self.inventory: # checking if the game is over
                self.game.endGame = True
                with open("Data/endGameMessage.txt", "r") as f:
                    toReturn = ""
                    for line in f:
                        toReturn+=line
                return toReturn
                
            else:
                return ("You see the huge main doors of the castle. Desperately, you try to open it, but it does not budge. your freedom is so painfully close, yet, it's so far away...\n") 
        elif direction not in self.directions:
            return("no such compass points exist\n")
        else:
            return("You walk blindly and hit the wall. Your head throbs for a while.\n")
            
        self.currentRoom = self.game.rooms[self.x][self.y]
        if self.currentRoom.ID == "[THRONEROOM]" and "Throne Room Key" not in self.inventory:
            self.currentRoom = self.game.rooms[pastX][pastY]
            self.x = pastX
            self.y = pastY
            return("There is a humongous door before you. It definitely leads to the throne room. You try to open it but it does not budge. Maybe you should find the key.\n")

        elif self.currentRoom.ID != self.game.rooms[pastX][pastY].ID:
            # updating the display
            self.gamePage.resetOutputText()
            return (self.currentRoom.displayDescription()+"\n").lstrip("\n")
 
    def take(self,item):
        ''' updates player's inventory accordingly'''
        if item not in self.currentRoom.objectsInRoom:
            return ("\nitem is not in the room\n")

        elif item in self.currentRoom.objectsInRoom and self.currentRoom.object[item]=="noTake": # checking if player can take the item
            article = " a" if item[0] not in self.vowels else " an"
            article = "" if item[-1]== "s" and "of" not in item.split() else article
            return("\nYou find no reason to lug around"+article+" "+item+"\n")
        
        try:
            if item in self.currentRoom.objectsInRoom:
                self.inventory.update({item:self.currentRoom.objectsInRoom.pop(item)}) # adding item to inventory
                if item in self.currentRoom.container["chest"]:
                    self.currentRoom.container["chest"].remove(item)
        except KeyError:
            pass
            
        self.currentRoom.removeItemFromDescription(item)
        toReturn = (item+" has been added to your inventory.\n")
        
        # appending extra information according to the item taken
        if item == "broom":
            toReturn+=("\nCongratulations! You have the ability to teleport! Type 'teleport' to teleport\n")

        elif item == "bucket":
            toReturn+=("\nLooks like you have got infinite power! You are found to be worthy to possess the power of...The BUCKET aka Gauntlet!!!\n")
            
        elif item == "dragon mail armor":
            toReturn+=("\nYou put on the ancient yet powerful armor.\n")
        return toReturn
    
    def open(self, chest):
        ''' when player opens a chest'''
        if chest != "chest":
            return ("\nYou cannot do that\n")
        
        if chest not in self.currentRoom.object:
            return ("\nthere is no chest in the room\n")
        if self.currentRoom.container["chest"] == []: # checking if chest is empty
            return "The chest is empty.\n"
        toReturn = ("\nitems in the chest are:\n")
        for item in self.currentRoom.container["chest"]:
            toReturn += item + "\n" # getting items in the chest
        
        return toReturn+("take an object if you want to, else you can leave the chest open. it will close when you exit room\n")


    def getAttackPower(self):     
        ''' gets the player's attack power'''   
        weaponDamageMult = 1
        if "bucket" in self.inventory:
            weaponDamageMult = 10**6
        elif "sword" in self.inventory:
            weaponDamageMult = 2
            
        return random.randint(3,7)*weaponDamageMult # returns the attack power
    
    def getArmorRating(self):
        '''gets the armour rating of the armour worn by player, if any'''
        if "dragon mail armor" in self.inventory:
            return 50 
        return 1
    
    def consume(self, item):
        '''to consume an item'''
        if item not in self.inventory:
            return ("\nThe item is not in your inventory\n")
        
        if not self.isConsumable(item):# checking if item is consumable
            return ("\nyou cannot consume this\n")
        
        if self.inventory[item][0] == "eat":
            self.health+=self.inventory[item][1]# increasing health of player
            amt = self.inventory[item][1]
        else:
            amt = random.randint(200,500)
            self.health+=amt# increasing health of player
            
        if self.health>self.max_health:
            self.health = self.max_health
        self.gamePage.updateHealthBar(amt)
        self.inventory.pop(item)
        self.gamePage.updateInventory()
        return ("\nyou consumed "+item+"\n")

    def isConsumable(self, item):
        '''checks if item is consumable'''
        if self.inventory[item][0] == "eat" or self.inventory[item][0] == "drink":
            return True
        return False
        
