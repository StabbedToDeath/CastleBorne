import random, colorsys

import kivy, os
from kivy.config import Config
Config.set('graphics','resizable',0)
Config.set('graphics','borderless', 1)
Config.set('kivy','log_level','error')
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import WindowBase
from kivy.lang import Builder
from kivy.properties import StringProperty, NumericProperty, ListProperty
from kivy.uix.behaviors.button import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.screenmanager import ScreenManager, Screen

import Game, Room

# adding necessary folder paths for kivy to recognize
kivy.resources.resource_add_path(os.path.dirname(os.path.abspath(__file__))+r"\Data\images")
kivy.resources.resource_add_path(os.path.dirname(os.path.abspath(__file__))+r"\Data\fonts")
Builder.load_file("Screens.kv")

class Castleborne(App):
    ''' the main app class'''
    page = None
    def build(self):
        sm = ScreenManager() # creating screen manager
        # adding screens
        Castleborne.page = GamePage(name = "gamePage")
        sm.add_widget(Menu(name="menu"))
        sm.add_widget(Help(name="help"))
        sm.add_widget(Castleborne.page)
        sm.add_widget(Story(name = "story"))
        return sm

class Menu(Screen):
    def initialize(self):
        # initializing game object
        Castleborne.page.game = Game.Game(Castleborne.page)
        Castleborne.page.game.placeKeyDefault()

class Help(Screen):
    helpBoxText = StringProperty()
    def display(self):
        out = ""
        with open("Data/help.txt", "r") as f:
            for line in f:
                out+=line
        self.helpBoxText = out # setting label's text to the help file's text
        
     
class GamePage(Screen):
    outputBoxText = StringProperty("")
    inventoryBoxText = StringProperty(" "*13+"INVENTORY\n")
    healthBarRectSizeX = NumericProperty(190)
    healthText = StringProperty("1000/1000")
    textHint = StringProperty("What do you want to do?")
    healthBarColor = ListProperty([0,255,0])
    
    def __init__(self, **kwargs):
        super(GamePage, self).__init__(**kwargs)
        # initializing game object
        self.game = Game.Game(self)
        
    def callCommands(self):
        commands = self.ids.input.text.split()
        out = ""
        # checking if command is valid and calling necessary function
        try:
            if self.game.player.health<=1 or self.game.endGame:
                self.manager.transition.direction = "left"
                self.manager.current = "menu"
                
            elif self.game.combat.inCombat:
                self.game.combat.initCombat()
                self.callAttackCommands()
                
            elif commands[0] == "go" and len(commands) == 2:
                out = self.game.player.goto(commands[1])
                out+=self.checkIfCombat()
                if self.game.endGame:
                    self.ids.input.disabled = True
                    self.textHint = "press confirm to go to menu"
                    
            elif commands[0] == "take":
                out = self.game.player.take(' '.join(commands[1:]))
                self.updateInventory()
            elif commands[0] == "open":
                out = self.game.player.open(commands[1])
            elif commands[0] == "eat" or commands[0] == "drink":
                out = self.game.player.consume(' '.join(commands[1:]))
                self.updateInventory()  
            elif commands[0] == "teleport" and "broom" in self.game.player.inventory:
                x,y = random.randint(0,3),random.randint(0,3)
                self.game.player.x = x
                self.game.player.y = y
                self.game.player.currentRoom = self.game.rooms[x][y]
                self.resetOutputText()
                out= "You have been teleported to "+self.game.player.currentRoom.ID[1:-1].lower()+"\n"
                out+=self.game.player.currentRoom.displayDescription()
                out+=self.checkIfCombat()
    
            #cheats
            elif commands == ["room","id"]:
                out = "\n"+self.game.player.currentRoom.ID
            elif commands[0]=="kill" and len(commands) == 1:
                self.updateHealthBar(-self.game.player.health)
                self.healthText = "0/1000"
                self.game.player.health=0
            elif commands == ["key","location"]:
                out = Room.Room.keyRoom.ID
            elif commands == ["unreveal","secrets"]:
                self.game.player.inventory.update({'bucket':'take','broom':'take'})
                self.updateInventory()
                out = "\nHow do you know that!!! Well we can't disrespect you so take what you asked for. Remember use it for your own good!!!"
            elif commands[0] == "goto":
                if commands[1] in Room.Room.roomNames:
                    for i in range(4):
                        for j in range(4):
                            if self.game.rooms[i][j].ID == commands[1]:
                                self.game.player.x = i
                                self.game.player.y = j
                                break
                    self.game.player.currentRoom = self.game.rooms[self.game.player.x][self.game.player.y]
                    self.resetOutputText()
                    out = (self.game.player.currentRoom.displayDescription()+"\n").lstrip("\n")
                    out+=self.checkIfCombat()
                else:
                    out = "You cannot do that"
            else:
                if not self.game.combat.inCombat:
                    out = "you cannot do that\n"
        except:
            self.Print("\n(Check your command)\n")
        
            
        self.Print(out) # updating the display
        self.ids.input.text = ""
        if self.game.player.health<=1: # checking if player is dead
            self.Print("\nYou breathe your last...with your eyes facing the ceiling, you die.")
            self.textHint = "press confirm to go back to menu"
            self.updateHealthBar(-100)
            self.ids.input.disabled = True
        elif not self.game.endGame:
            Clock.schedule_once(self.focusInput)
    
    def callAttackCommands(self):
        # calling functions in combat class
        out = self.game.combat.checkCommandAndCall(self.ids.input.text)
        self.Print(out)
        if not self.game.combat.isAttacking and not self.game.combat.isUsingItem:
            out = self.game.combat.enemiesAttack()
            if out != "":
                self.Print(out[0])
                for damage in out[1]:
                    # updating health bar
                    self.updateHealthBar(-damage)
            out = self.game.combat.isCombatOver()
            self.Print(out)
        
    def updateHealthBar(self, amt=1):
        amt = round((190./1000)*(amt),2) # amount by which health bar should reduce
        self.healthText = (str(int(self.game.player.health)) if self.game.player.health>0 else "0")+"/1000"
        self.healthBarRectSizeX += amt
        
        self.healthBarColor = self.getColor(self.game.player.health/10) # setting color of the health bar
        
        if self.healthBarRectSizeX<=0:
            self.healthBarRectSizeX = 0
    def getColor(self, amt):
        return list(colorsys.hls_to_rgb((amt*(1.2/360)), .5, 1))

    def Print(self, text):
        if text == "" or text.split() == []:
            return
        self.outputBoxText += text #updates the display
      
    def setProperties(self):
        # setting the variables connected to the widgets to default values
        self.outputBoxText =""
        self.inventoryBoxText = " "*13+"INVENTORY\n"
        self.healthBarRectSizeX = 190
        self.healthText = "1000/1000"
        self.textHint = "What do you want to do?"
        self.healthBarColor = [0,255,0]
        
    
    def updateInventory(self, *args):
        # updates the inventory label
        self.inventoryBoxText=" "*13+"INVENTORY\n"+"\n".join(self.game.player.inventory.keys())  
    
    def focusInput(self, *args):
        self.ids.input.focus = True
    
    def setOutputBoxText(self):
        # sets the display at the start of the game
        self.outputBoxText = "You are finally inside the game! I've been waiting..."+self.game.player.currentRoom.displayDescription()

    def resetOutputText(self):
        # resets the display
        self.outputBoxText = ""
    
    def checkIfCombat(self):
        # checks if the player is in combat
        if self.game.player.currentRoom.enemies!=[]:
            self.game.combat.inCombat = True
            return "You have entered a fight for you life! In this battle, you can attack, defend or use an item before the enemy attacks!"
        return ""
    
class Exit_Button(ButtonBehavior, Image):
    def Exit(self):
        Win().exit() #closes the window
        App.get_running_app().stop() #stops the app

class Story(Screen):
    storyText = StringProperty()
    def display(self):
        out = ""
        with open("Data/intro.txt", "r") as f:
            for line in f:
                out+=line
        self.storyText = out # setting label's text to the intro file's text 
        
class Win(WindowBase):
    def exit(self):
        self.close() # closing the window
        
if __name__ == "__main__":
    Castleborne().run() # running the app
    
