class Room():
    '''represents a room'''
    isKeyPlaced = False
    keyRoom = None
    roomNames = {"[ALCHEMYROOM]" : "you are in the alchemy room", "[RC]":"you are in the recreation room", "[LOBBY]": "you are in the lobby", "[GARDEN]":"you are in the garden", "[HAUNTEDROOM]":"you are in the haunted room of the castle", "[SERVANTQUATERS]":"you are in the servant quarters", "[MAINHALL]":"you are in the main hall", "[BALCONY]":"you are in the balcony", "[TEMPLE]":"you are facing the castle's mysterious shrine", "[MISC]":"you don't the name of the room", "[THRONEROOM]":"you are in the throne room", "[KITCHEN]":"you are in the kitchen", "[STORAGE]":"you are in the storage room", "[ARMOURY]":"you are in the armory", "[PUNDUNGEON]":"you are in the dungeon of puns","[DUNGEON]":"you are in the dungeon"}
    def __init__(self, page, objectsFile, ID):
        '''initializing variables'''
        self.description = ""
        self.north = []
        self.south = []
        self.east = []
        self.west = []
        self.container = {}
        self.object = {}
        self.objectsInRoom={}
        self.notes = {}
        self.enemies = []
        self.objectsFile = objectsFile
        self.ID = ID
        self.loadObjects()
        self.gamePage = page;

    def loadObjects(self):
        '''loading objects for the room'''
        self.objectsFile.seek(0)
        while True:
            line = self.objectsFile.readline()
            if line=="":
                break
            if line.strip()==self.ID:
                for line in self.objectsFile:
                    if line.strip()=="}":
                        break
                    l = map(str.strip, line.split("="))
                    if l[0]=="container":
                        self.container.update(eval(l[1]))
                    elif l[0]=="object":
                        self.object.update(eval(l[1]))
                    elif l[0]=="note":
                        self.notes.update(eval(l[1]))
                    elif l[0]=="description":
                        self.description+=eval(l[1])
                    elif l[0] == "enemy":
                        self.enemies.append(eval(l[1]))
                    elif l[0]=="objectLocation":
                        d = eval(l[1])
                        d[d.keys()[0]] = d[d.keys()[0]][1:]
                        direc = eval(l[1])[eval(l[1]).keys()[0]][0]
                        if direc == "north":
                            self.north.append(d)
                        elif direc == "south":
                            self.south.append(d)
                        elif direc == "east":
                            self.east.append(d)
                        elif direc == "west":
                            self.west.append(d)
                break             
        
        self.objectsInRoom = dict(self.object)
             

    def displayDescription(self):
        '''gets the current description of the room'''
        toReturn =("You look around, and with your keen senses you come to the conclusion that "+Room.roomNames[self.ID]+" .")
        n=self.getItems(self.north, "north")
        s=self.getItems(self.south, "south")
        e=self.getItems(self.east, "east")
        w=self.getItems(self.west, "west")
        north = south = east = west = ""
        if n!="":
            north = "in the north there "+("is "if n.split()[0] != "are" else "")+ (n if self.north != [] else "")
        if s!="":
            south = " In the south there "+("is "if s.split()[0] != "are" else "") + (s if self.south != [] else "")
        if e!="":
            east = " In the east there "+("is "if e.split()[0] != "are" else "") + (e if self.east != [] else "")
        if w!="":
            west = " In the west there "+("is "if w.split()[0] != "are" else "") + (w if self.west != [] else "")
        if n!="" or s!="" or e!="" or w!="":
            toReturn+=(" Also, you notice that "+ north+south+east+west+"\n")
            if self.gamePage.game.player.currentRoom.ID == "[MAINHALL]":
                toReturn+="Despite seeing so many useful items on stands, you cannot take them. They seemed to be glued to their stands."
            toReturn+="\n"+self.description
            return toReturn
        else:
            return toReturn+(" Also, you notice that there is nothing here that you can take.\n")+"\n"+self.description
            

    def getItems(self, l, direc):
        '''joins the names of the objects in the room into one appropriate sentence'''
        if len(l) == 0:
            return ""
        var = ""
        vowel = ("a", "e", "i", "o", "u")
        for i in range(len(l) if l[-1].keys()[0] != "table" else len(l)-1):
            d= l[i]
            article = "a " if (d.keys()[0][0].lower() not in vowel) else ("an " if d.keys()[0][0].islower() else "")
            article = "are " if (d.keys()[0][-1]== "s" and 'of' not in d.keys()[0].split()) else article
            if i!= len(l)-1:
                var+=article+d.keys()[0]+(", " if (len(l) - (["table"] in map(dict.keys, l))) != 1 else "")
            else:
                var+=article + d.keys()[0] 
        if l[-1].keys()[0] == "table" and len(l[-1][l[-1].keys()[0]]) != 0:
            var += ((" and ") if len(var)!=0 else "")+ ("a table that consists of ")
            t = l[-1][l[-1].keys()[0]]
            if len(t) != 0:
                for i in range(len(t)):
                    article = "a " if t[i][0] not in vowel else "an "
                    article = "" if t[i][-1] == "s" else article
                    if i!=len(t)-1:
                        var+=article+t[i]+","
                    elif len(t)==1:
                        var+=article+t[i]+". "
                    elif i==len(t)-1 and len(t)!=1:
                        var = var[:-1]
                        var+=" and "+article+t[i]+". "
        elif var[:-2].rfind(",") != -1:
            if var[-1]=="," or (var[-1] == " " and var[-2] == ","):
                var = var[:var[:-2].rfind(",")]+" and"+var[var[:-2].rfind(",")+1:-2]+"."
            else:
                var = var[:var[:-2].rfind(",")]+" and"+var[var[:-2].rfind(",")+1:]+"."
        elif var[-1]==",":
            var = var[:-2]+"."
        else:
            var+=". "
        return var

    def removeItemFromDescription(self, item):
        '''removes an item from description'''
        self.removeItem(self.north, item)
        self.removeItem(self.south, item)
        self.removeItem(self.east, item)
        self.removeItem(self.west, item)

    def removeItem(self, l, item):
        '''removes an item from a single list'''
        for i in range(len(l)):
            if item in l[i]:
                l.pop(i)
                break
            elif "table" in l[i] and item in l[i]["table"]:
                l[i]["table"].remove(item)
                break
