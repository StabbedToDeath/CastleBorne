import random
class Enemy():
    '''represents an enemy'''
    def __init__(self, name, health):
        '''initializing variables'''
        self.health = health
        self.name = name
        self.attacks = []
        self.defenceMult = 1
        self.loadAttacks()

    def loadAttacks(self):
        '''loading attacks from files'''
        with open("data/Enemies.txt", "r") as f:
            for l in f:
                if l[0] == "[" and ' '.join(l.split())[1:-1] == self.name:
                    for line in f:
                        if line[0] == "{":
                            continue
                        elif line[0] == "}":
                            break
                        line = line.split("=")
                        self.attacks.append(eval(line[1]))
                    break

    def getAttack(self):
        '''getting a random attack'''
        attack = self.attacks[random.randint(0,len(self.attacks)-1)]
        return attack[0],attack[1]*random.uniform(0.75,1.00)
        
