import random
class Player():
    '''represents a player'''
    def __init__(self, game):
        '''initializing variables'''
        self.x = 0
        self.y = 2
        self.currentRoom = game.rooms[self.x][self.y]
        self.inventory = {}
        self.game = game
        self.health = 1000
        self.max_health = 1000
        self.defenceMult = 1
        self.directions = ["north", "south", "east", "west"]
        self.vowels= ["a","e","i","o","u"]
    
    def goto(self,direction):
        ''' changes the player location according to the input'''
        pastX = self.x
        pastY = self.y
        # checking if direction is valid and applying necessary changes
        if direction == "north" and self.x-1>=0:
            self.x-=1
        elif direction == "south" and self.x+1<=3:
            self.x+=1
        elif direction == "east" and self.y+1<=3:
            self.y+=1
        elif direction == "west" and self.y-1>=0:
            self.y-=1
        elif direction == "north" and self.currentRoom.ID == "[LOBBY]":
            if "Castle Key" in self.inventory: # checking if the game is over
                with open("Data/endGameMessage.txt", "r") as f:
                    for line in f:
                        print line,
                self.game.endGame = True
            else:
                print "You see the huge main doors of the castle. Desperatly, you try to open it, but it does not budge. your freedom is so painfully close, yet, it's so far away..." 
        elif direction not in self.directions:
            print "no such compass points exist"
            return
        else:
            print "You walk blindly and hit the wall. Your head throbs for a while."
            return
        self.currentRoom = self.game.rooms[self.x][self.y]
        if self.currentRoom.ID == "[THRONEROOM]" and "Throne Room Key" not in self.inventory:
            print "There is a humongous door before you. It definitely leads to the throne room. You try to open it but it does not budge. Maybe you should find the key."
            self.currentRoom = self.game.rooms[pastX][pastY]
            self.x = pastX
            self.y = pastY
        elif self.currentRoom.ID != self.game.rooms[pastX][pastY].ID:
            self.currentRoom.displayDescription() # printing room's description

    def take(self,item):
        ''' updates player's inventory accordingly'''
        if item not in self.currentRoom.objectsInRoom and item not in self.currentRoom.notes:
            print "item is not in the room"
            return
        elif item in self.currentRoom.objectsInRoom and self.currentRoom.object[item]=="noTake":# checking if player can take the item
            article = " a" if item[0] not in self.vowels else " an"
            article = "" if item[-1]== "s" and len(item.split())==1 else article
            print "You find no reason to lug around"+article+"",item
            return
        
        try:
            if item in self.currentRoom.objectsInRoom:
                self.inventory.update({item:self.currentRoom.objectsInRoom.pop(item)}) # adding item to inventory
                if item in self.currentRoom.container["chest"]:
                    self.currentRoom.container["chest"].remove(item)
        except KeyError:
            pass
            
        print item,"has been added to your inventory."
        self.currentRoom.removeItemFromDescription(item)
        # printing extra information according to the item taken
        if item == "broom":
            print "Congratulations! You have the ability to teleport! Type 'teleport' to teleport"

        elif item == "bucket":
            print "Looks like you have got infinite power! You are found to be worthy to posses the power of...The BUCKET aka Gauntlet!!!"

        elif item == "dragon mail armor":
            print "You put on the ancient yet powerful armor."
    def Open(self, chest):
        ''' when player opens a chest'''
        if chest != "chest":
            print "You cannot do that"
            return
        if chest not in self.currentRoom.object:
            print "there is no chest in the room"
            return
        if self.currentRoom.container["chest"] == []: # checking if chest is empty
            return "The chest is empty.\n"

        print "items in the chest are:"
        for item in self.currentRoom.container["chest"]:
            print item # printing items in the chest

        print "\ntake an object if you want to, else you can leave the chest open. it will close when you exit room"

        
    def seeInventory(self):
        '''displays items inventory'''
        if self.inventory == {}:
            print "There are no items in your inventory."
            return
        
        print "The items in your inventory are:"
        for item in self.inventory:
            print item

    def getAttackPower(self):
        ''' gets the player's attack power'''   
        weaponDamageMult = 1
        if "bucket" in self.inventory:
            weaponDamageMult = 10**6
        elif "sword" in self.inventory:
            weaponDamageMult = 2
            
        return random.randint(3,7)*weaponDamageMult# returns the attack power

    def getArmorRating(self):
        '''gets the armour rating of the armour worn by player, if any'''
        if "dragon mail armor" in self.inventory:
            return 50 
        return 1
    
    def consume(self, item):
        '''to consume an item'''
        if item not in self.inventory:
            print "The item is not in your inventory"
            return
        
        if not self.isConsumable(item):# checking if item is consumable
            print "you cannot consume this"
            return
        
        if self.inventory[item][0] == "eat":
            self.health+=self.inventory[item][1]# increasing health of player
        else:
            self.health+=random.randint(200,500)# increasing health of player
        if self.health>self.max_health:
            self.health = self.max_health
        print "you consumed",item+". Your health is now",self.health
        self.inventory.pop(item)

    def isConsumable(self, item):
        '''checks if item is consumable'''
        if self.inventory[item][0] == "eat" or self.inventory[item][0] == "drink":
            return True
        return False
        
