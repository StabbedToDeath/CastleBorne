import Player, Room, CombatSystem
import random
class Game():
    '''represents the game'''
    def __init__(self):
        '''initializing variables'''
        self.rooms = [[0 for i in range(4)] for i in range(4)]
        self.loadRooms()
        self.placeKeyDefault()
        self.player = Player.Player(self)
        self.combat = CombatSystem.CombatSystem(self.player)
        self.endGame = False
        self.start()
    def run(self):
        print "You are inside the game finally and now lets begin the task. So in the end we will know that the game will have you or you will have the game."
        self.player.currentRoom.displayDescription()
        while True:
            if self.player.health<=0: #checking if player is dead
                print "You breathe your last...with your eyes facing the ceiling, you die."
                break
            Input = raw_input("What do you want to do?\n")#gathering input
            commands = Input.split()
            # checking if command is valid and calling necessary function
            if commands[0] == "go":
                self.player.goto(commands[1])
                if self.player.currentRoom.enemies!=[]:
                    self.combat.startCombat()
                    continue
                
            elif commands[0] == "take":
                self.player.take(' '.join(commands[1:]))
            elif commands[0] == "open":
                self.player.Open(commands[1])
            elif commands == ["see","inventory"] or commands == ["show", "inventory"]:
                self.player.seeInventory()
            elif commands == ["see", "health"]:
                print "Your current health is",self.player.health,"\n"
                continue
            elif commands[0] == "eat" or commands[0] == "drink":
                self.player.consume(' '.join(commands[1:]))
            elif commands[0] == "teleport" and "broom" in self.player.inventory:
                x,y = random.randint(0,3),random.randint(0,3)
                self.player.x = x
                self.player.y = y
                self.player.currentRoom = self.rooms[x][y]
                print "You have been teleported to",self.player.currentRoom.ID[1:-1].lower()
                self.player.currentRoom.displayDescription()
                if self.player.currentRoom.enemies!=[]:
                    self.combat.startCombat()
                    continue

            #cheats
            elif commands == ["room","id"]:
                print self.player.currentRoom.ID
            elif commands == ["enemy","count"]:
                print "Number of enemies:",len(self.player.currentRoom.enemies)
            elif commands[0]=="kill":
                self.player.health=0
            elif commands == ["key","location"]:
                print Room.Room.keyRoom.ID
            elif commands == ["unreveal","secrets"]:
                self.player.inventory.update({'bucket':'take','broom':'take'})
                print "How do you know that!!! Well we cant disrespect you so take what you asked for.Remember use it for your own good!!!"
            elif commands[0] == "goto":
                if commands[1] in Room.Room.roomNames:
                    for i in range(4):
                        for j in range(4):
                            if self.rooms[i][j].ID == commands[1]:
                                self.player.x = i
                                self.player.y = j
                                break
                    self.player.currentRoom = self.rooms[self.player.x][self.player.y]
                    self.player.currentRoom.displayDescription()
                    if self.player.currentRoom.enemies!=[]:
                        self.combat.startCombat()
                        continue
            else:
                print "you cannot do that\n"
                continue
            if self.endGame: #checking if game is over
                break
            print

    def start(self):
        '''to start the game'''
        #displaying into text
        with open("Data/help.txt","r") as f:
            for line in f:
                print line,
        raw_input("Press enter to start!")
        self.run()
    
    def loadRooms(self):
        ''' initializes the rooms of the game'''
        objectsFile = open("data/Objects.txt","r")
        with open("data/rooms.txt", "r") as f:
            for line in f:
                l = map(str.strip, line.split("="))
                self.rooms[int(l[1][1])][int(l[1][-2])] = Room.Room(self, objectsFile, l[0])
        objectsFile.close()

    def placeKeyDefault(self):
        '''placeskey in random room'''
        if not Room.Room.isKeyPlaced:
            while True:
                x = random.randint(0,3)
                y = random.randint(0,3)
                if self.rooms[x][y].container != {}:
                    Room.Room.isKeyPlaced = True
                    Room.Room.keyRoom = self.rooms[x][y]
                    self.rooms[x][y].object.update({"Throne Room Key":"take"})# adding key to the room
                    l = self.rooms[x][y].container['chest']
                    l.append("Throne Room Key")
                    self.rooms[x][y].container['chest'] = l
                    self.rooms[x][y].objectsInRoom = dict(self.rooms[x][y].object)
                    break
game = Game() #creating object and starting the program
