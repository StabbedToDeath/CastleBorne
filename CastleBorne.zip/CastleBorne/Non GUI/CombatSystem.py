import random
import Enemy
class CombatSystem:
    '''represents the combat system'''
    def __init__(self, player):
        '''initialising variables'''
        self.player = player
        self.playerDamageAbsorb = 1
        self.enemies = {}
        
    def initCombat(self):
        '''initialing combat'''
        print "\nYou have entered a fight for you life! In this battle, you can attack, defend or use an item before the enemy attacks!"
        self.enemies = {}
        self.playerDamageAbsorb = self.player.getArmorRating()
        for t in self.player.currentRoom.enemies:
            for i in range(t[1]):
                self.enemies[(t[0]+(" "+str(i+1) if t[1]!=1 else "")).lower()] = Enemy.Enemy(t[0], t[-1])
            
    def startCombat(self):
        self.initCombat()
        while True:
            if self.player.health<=0:
                break
            choice = raw_input("\nWhat do you want to do?\n")#gathering input

            #checking commands and performing appropriate actions
            if choice != "attack" and choice != "defend" and choice != "use an item" and choice != "kill all":
                print "you cannot do that"
                continue

            if choice == "kill all":
                self.enemies = {}

            elif choice == "attack":
                self.displayEnemies()
                while True:
                    target = raw_input("Which enemy do you want to attack? ").lower()
                    if target not in self.enemies:
                        print "That enemy is not present"
                        continue
                    break
                self.enemies[target].health-=(self.player.getAttackPower()/self.enemies[target].defenceMult)# decreasing target's health
                if self.enemies[target].health<1:
                    print "You killed", target+"!"
                    self.enemies.pop(target)
                else:
                    print "You attacked",target+"!"
                if "bucket" in self.player.inventory:
                    print "You have done one hundred novemdecillion(10^62) attack damage!!!!!!!!!!!"
                    

            elif choice == "defend":
                self.playerDamageAbsorb = self.player.defenceMult+random.uniform(0.5, 1) #increasing defence of player
                print "You have defended!"

            elif choice == "use an item":
                l = []
                for item in self.player.inventory:
                    if self.player.isConsumable(item):
                        l.append(item)
                if l!=[]:
                    print "The items you can use are:"
                    for item in l:
                        print item #printing usable items
                    while True:
                        item = raw_input("Which item do you want to use? ")
                        if item not in l:
                            print "you cannot use that item"
                            continue
                        break
                    self.player.consume(item) #consuming item
                else:
                   print "you don't have any items you can use during combat."
            print
            
            if self.enemies == {}:
                #checking if combat is over
                print "You have won the battle!"
                self.player.currentRoom.enemies = []
                if self.player.currentRoom.ID == "[THRONEROOM]":
                    print "\nYou rummage through the corpse, looking for something of value. You find a large number of items, despite the fact that the monster didn't have pockets to begin with. You also find a rusty key, which looks like it fits into the lock of the castle's main door. Nearly crying with joy, you realize that you can finally get out of this hell hole. You make your way to the lobby.\n"
                    self.player.inventory.update({"Castle Key":"take"})
                    
                break


            for enemy in self.enemies:
                self.enemies[enemy].defenceMult = 1
                notMiss = bool(random.randint(0,3))
                if not notMiss:
                    print enemy,"has missed his attack!"
                    continue
                attackChance = bool(random.randint(0,3))
                if attackChance:
                    attack = self.enemies[enemy].getAttack()
                    print enemy+attack[0]
                    self.player.health-=attack[1]/self.playerDamageAbsorb #decreasing player health
                    print "your health is",round(self.player.health, 2)
                else:
                    self.enemies[enemy].defenceMult+=random.uniform(0.25,0.75)#increasing enemy defence variable
                    print enemy, "has defended!"
                    
            self.playerDamageAbsorb = self.player.getArmorRating()

        return     
                    
    def displayEnemies(self):
        ''' displays enemies in room along with their healths'''
        print "Enemies around you:"
        for i in self.enemies:
            print i+"%30d"%self.enemies[i].health
